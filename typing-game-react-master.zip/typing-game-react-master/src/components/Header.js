import React from 'react';

class Header extends React.Component {
	render() {
		return (
			<header>
				<h1>React Typing Game</h1>
				{/* 
					<ul>
						<li><a href="#">Login</a></li>
						<li><a href="#">Sign up</a></li>
					</ul>
				*/}
			</header>
		)
	}
}

export default Header;