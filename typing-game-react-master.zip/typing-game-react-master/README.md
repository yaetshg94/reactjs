# Cathy's React Typing Game
This is a typing game created with React, Webpack, SASS

## Quick Start
Try the game: [https://react-typing-game.herokuapp.com/](https://react-typing-game.herokuapp.com/).

## Installing
```
yarn install
```

## Building
```
yarn run dev
```



